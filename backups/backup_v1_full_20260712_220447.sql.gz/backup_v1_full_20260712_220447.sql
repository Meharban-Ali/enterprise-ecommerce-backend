-- Ecommerce Redis Application Database Backup
-- Version: 1
-- Type: FULL
-- Timestamp: 2026-07-12T22:04:47.542978200
CREATE TABLE products (id INT, name VARCHAR(255), price DECIMAL);
CREATE TABLE users (id INT, email VARCHAR(255), role VARCHAR(50));
CREATE TABLE orders (id INT, total DECIMAL, status VARCHAR(50));
CREATE TABLE payments (id INT, amount DECIMAL, status VARCHAR(50));
