-- Ecommerce Redis Application Database Backup
-- Version: 5
-- Type: FULL
-- Timestamp: 2026-07-12T17:12:55.048159700
CREATE TABLE products (id INT, name VARCHAR(255), price DECIMAL);
CREATE TABLE users (id INT, email VARCHAR(255), role VARCHAR(50));
CREATE TABLE orders (id INT, total DECIMAL, status VARCHAR(50));
CREATE TABLE payments (id INT, amount DECIMAL, status VARCHAR(50));
